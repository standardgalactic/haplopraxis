# Haplopraxis

A tiny web game where **history is the world**.

There is no state machine to “solve.”
There is only an event lineage that permanently narrows the future.

## Run locally

Open `index.html` in a browser.

## Deploy to GitHub Pages

1. Create a new GitHub repo.
2. Add these files to the repo root.
3. Repo → **Settings → Pages** → Deploy from `main` / root.
4. Open the provided Pages URL.

## Share worlds

Use **Export** to copy your lineage (JSON).
Send it to a friend.
They can **Import** to excavate your world as an archaeological record.

Imported worlds are **read-only**: archaeology, not intervention.

## Files

- `index.html` — main page
- `styles.css` — CRT styling
- `game.js` — the game engine (event sourcing)
- `sample-lineage.json` — a small example lineage you can import
