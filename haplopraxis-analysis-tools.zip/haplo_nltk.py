from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from pathlib import Path
import math
import re

import nltk
from nltk.collocations import BigramCollocationFinder, BigramAssocMeasures

from common import load_docs, tokenize

STOP = {
    "the","and","for","that","with","this","from","are","was","were","into","you",
    "your","but","not","have","has","had","its","they","their","then","than","can",
    "will","would","there","which","when","what","who","how","all","any","our","out",
    "use","using","used","file","files","http","https","www","com","org","github",
    "html","true","false","none","let","const","function","return"
}

DEFAULT_CONCEPTS = [
    "history", "lineage", "opacity", "continuity", "inheritocracy", "dissipative",
    "terminal", "relational", "architecture", "resource", "fabrication",
    "starfield", "watchlist", "galactic", "phaistos", "prometheus", "replay"
]

def content_tokens(text):
    return [w for w in tokenize(text) if len(w) > 2 and w not in STOP]

def concordance(text, term, width=55, max_hits=8):
    low = text.lower()
    term_low = term.lower()
    out = []
    pos = 0
    while len(out) < max_hits:
        i = low.find(term_low, pos)
        if i < 0:
            break
        a = max(0, i-width)
        b = min(len(text), i+len(term)+width)
        snippet = re.sub(r"\s+", " ", text[a:b]).strip()
        out.append(snippet)
        pos = i + len(term)
    return out

def main():
    ap = argparse.ArgumentParser(description="NLTK corpus archaeology for Haplopraxis.")
    ap.add_argument("root", type=Path)
    ap.add_argument("--top", type=int, default=30)
    ap.add_argument("--concept", action="append", default=[])
    args = ap.parse_args()

    docs = load_docs(args.root)
    if not docs:
        raise SystemExit("No text-like files found.")

    per_doc = {}
    global_tokens = []
    docfreq = Counter()

    for d in docs:
        toks = content_tokens(d.text)
        per_doc[d.rel] = toks
        global_tokens.extend(toks)
        docfreq.update(set(toks))

    freq = Counter(global_tokens)
    print(f"documents: {len(docs)}")
    print(f"content tokens: {len(global_tokens):,}")
    print(f"vocabulary: {len(freq):,}")

    print("\nFrequent repository vocabulary:")
    for w, n in freq.most_common(args.top):
        print(f"{w:24s} {n:8d}  docs={docfreq[w]:4d}")

    finder = BigramCollocationFinder.from_words(global_tokens)
    finder.apply_freq_filter(3)
    scored = finder.score_ngrams(BigramAssocMeasures.likelihood_ratio)
    print("\nStrong bigram collocations:")
    for (a, b), score in scored[:args.top]:
        print(f"{a} {b:20s} {score:9.2f}")

    concepts = DEFAULT_CONCEPTS + [c.lower() for c in args.concept]
    concepts = list(dict.fromkeys(concepts))

    print("\nConcept migration:")
    for c in concepts:
        hits = []
        for d in docs:
            n = per_doc[d.rel].count(c)
            if n:
                hits.append((n, d.rel))
        if not hits:
            continue
        hits.sort(reverse=True)
        print(f"\n{c} — {sum(n for n,_ in hits)} hits across {len(hits)} files")
        for n, rel in hits[:6]:
            print(f"  {n:4d}  {rel}")

    # TF-IDF-like "signature vocabulary" per document
    N = len(docs)
    print("\nDocument signature vocabulary:")
    for d in sorted(docs, key=lambda x: len(per_doc[x.rel]), reverse=True)[:15]:
        c = Counter(per_doc[d.rel])
        scored_words = []
        for w, tf in c.items():
            if tf < 2:
                continue
            idf = math.log((1 + N) / (1 + docfreq[w])) + 1
            scored_words.append((tf * idf, w, tf, docfreq[w]))
        scored_words.sort(reverse=True)
        sig = ", ".join(w for _, w, _, _ in scored_words[:8])
        print(f"{d.rel}: {sig}")

    # Concordances for explicitly requested concepts, or three central defaults.
    chosen = args.concept or ["history", "lineage", "opacity"]
    print("\nConcordances:")
    joined = "\n".join(d.text for d in docs)
    for c in chosen:
        hits = concordance(joined, c)
        if not hits:
            continue
        print(f"\n[{c}]")
        for h in hits:
            print("...", h, "...")

if __name__ == "__main__":
    main()
