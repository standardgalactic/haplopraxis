from __future__ import annotations

import argparse
from collections import Counter
from pathlib import Path
import csv
import math
import random

import numpy as np

from common import load_docs, tokenize, git_first_commit_timestamp

DEFAULT_CONCEPTS = [
    "history", "world", "lineage", "opacity", "developmental", "continuity",
    "inheritocracy", "dissipative", "terminal", "relational", "architecture",
    "fabrication", "resource", "starfield", "watchlist", "galactic", "phaistos",
    "prometheus", "replay", "encounter", "order", "state"
]

def vectorize(docs, max_terms=2500):
    dfs = Counter()
    tokenized = []
    for d in docs:
        toks = tokenize(d.text)
        tokenized.append(toks)
        dfs.update(set(toks))

    vocab = [
        w for w, df in dfs.most_common(max_terms)
        if len(w) > 2 and df >= 2
    ]
    index = {w: i for i, w in enumerate(vocab)}

    X = np.zeros((len(docs), len(vocab)), dtype=np.float64)
    for i, toks in enumerate(tokenized):
        c = Counter(toks)
        for w, n in c.items():
            j = index.get(w)
            if j is not None:
                X[i, j] = 1.0 + math.log(n)

    if len(docs):
        idf = np.log((1 + len(docs)) / (1 + np.array([dfs[w] for w in vocab]))) + 1
        X *= idf

    norms = np.linalg.norm(X, axis=1, keepdims=True)
    X = np.divide(X, norms, out=np.zeros_like(X), where=norms != 0)
    return vocab, X

def concept_matrix(docs, concepts):
    M = np.zeros((len(docs), len(concepts)), dtype=float)
    for i, d in enumerate(docs):
        c = Counter(tokenize(d.text))
        total = max(sum(c.values()), 1)
        for j, concept in enumerate(concepts):
            M[i, j] = 1000.0 * c[concept.lower()] / total
    return M

def order_sensitivity(M, trials=1000, seed=42):
    if len(M) < 2:
        return 0.0, 0.0
    rng = random.Random(seed)
    n = len(M)
    # Earlier encounters are weighted more heavily, modeling "the order you see things
    # changes the autopsy."
    weights = np.exp(-np.linspace(0, 3.0, n))
    weights /= weights.sum()

    vals = []
    for _ in range(trials):
        order = list(range(n))
        rng.shuffle(order)
        exposure = (M[order] * weights[:, None]).sum(axis=0)
        vals.append(float(np.linalg.norm(exposure)))
    return float(np.mean(vals)), float(np.std(vals))

def main():
    ap = argparse.ArgumentParser(description="NumPy repository archaeology for Haplopraxis.")
    ap.add_argument("root", type=Path)
    ap.add_argument("--top", type=int, default=15)
    ap.add_argument("--matrix-out", type=Path)
    ap.add_argument("--concept", action="append", default=[])
    args = ap.parse_args()

    docs = load_docs(args.root)
    if not docs:
        raise SystemExit("No text-like files found.")

    counts = np.array([len(tokenize(d.text)) for d in docs], dtype=float)
    lines = np.array([d.text.count("\n") + 1 for d in docs], dtype=float)
    richness = np.array([
        len(set(tokenize(d.text))) / max(len(tokenize(d.text)), 1)
        for d in docs
    ])

    print(f"documents: {len(docs)}")
    print(f"tokens: {int(counts.sum()):,}")
    print(f"median tokens/file: {np.median(counts):.0f}")
    print(f"mean lines/file: {np.mean(lines):.1f}")
    print(f"median lexical richness: {np.median(richness):.3f}")

    vocab, X = vectorize(docs)
    S = X @ X.T

    pairs = []
    for i in range(len(docs)):
        for j in range(i + 1, len(docs)):
            if S[i, j] > 0:
                pairs.append((float(S[i, j]), docs[i].rel, docs[j].rel))
    pairs.sort(reverse=True)

    print("\nMost similar document pairs:")
    for score, a, b in pairs[:args.top]:
        print(f"{score:0.3f}  {a}  <->  {b}")

    concepts = DEFAULT_CONCEPTS + [x.lower() for x in args.concept]
    concepts = list(dict.fromkeys(concepts))
    M = concept_matrix(docs, concepts)

    print("\nConcept concentration (occurrences per 1000 tokens):")
    for j, c in enumerate(concepts):
        col = M[:, j]
        if np.max(col) <= 0:
            continue
        idx = np.argsort(col)[::-1][:3]
        tops = ", ".join(
            f"{docs[i].rel}={col[i]:.2f}"
            for i in idx if col[i] > 0
        )
        print(f"{c:16s} {tops}")

    mean_os, sd_os = order_sensitivity(M)
    print("\nEncounter-order sensitivity:")
    print(f"weighted concept-exposure norm = {mean_os:.4f} ± {sd_os:.4f}")
    print("Higher dispersion means document order materially changes the aggregate conceptual profile.")

    dated = []
    for d in docs:
        ts = git_first_commit_timestamp(args.root, d.rel)
        if ts is not None:
            dated.append((ts, d))
    if dated:
        dated.sort()
        print("\nRepository strata:")
        chunks = np.array_split(np.arange(len(dated)), min(5, len(dated)))
        for k, idxs in enumerate(chunks, 1):
            subset = [dated[int(i)][1] for i in idxs]
            tok = sum(len(tokenize(d.text)) for d in subset)
            print(f"stratum {k}: {len(subset):3d} files, {tok:8d} tokens, "
                  f"{subset[0].rel} ... {subset[-1].rel}")

    if args.matrix_out:
        with args.matrix_out.open("w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["file"] + [d.rel for d in docs])
            for d, row in zip(docs, S):
                w.writerow([d.rel] + [f"{x:.6f}" for x in row])
        print(f"\nwrote {args.matrix_out}")

if __name__ == "__main__":
    main()
