from __future__ import annotations

import argparse
from pathlib import Path
import subprocess
import sys

def run(script, root):
    print("\n" + "=" * 78)
    print(script)
    print("=" * 78)
    subprocess.run([sys.executable, script, str(root)], check=False)

def main():
    ap = argparse.ArgumentParser(description="Run Haplopraxis repository analyses.")
    ap.add_argument("root", type=Path)
    args = ap.parse_args()

    here = Path(__file__).resolve().parent
    run(str(here / "haplo_numpy.py"), args.root)
    run(str(here / "haplo_nltk.py"), args.root)

    print("\n" + "=" * 78)
    print("haplo_sympy.py")
    print("=" * 78)
    subprocess.run([sys.executable, str(here / "haplo_sympy.py"), "--derive"], check=False)

if __name__ == "__main__":
    main()
