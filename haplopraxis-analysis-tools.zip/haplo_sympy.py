from __future__ import annotations

import argparse
import sympy as sp

def build_model():
    # O: presently observable state
    # H: historically inherited state
    # E: encounter history / path dependence
    # R: repair/replay/reconstruction accessibility
    # D: dissipation
    O, H, E, R, D = sp.symbols("O H E R D", nonnegative=True)
    alpha, beta, gamma, delta = sp.symbols(
        "alpha beta gamma delta", positive=True
    )
    t = sp.symbols("t", nonnegative=True)

    hidden_history = H * sp.exp(-delta * D * t)
    encounter_trace = alpha * E / (1 + beta * t)
    recoverable_history = gamma * R * hidden_history

    full_state = O + hidden_history + encounter_trace
    observable_reconstruction = O + recoverable_history

    # Developmental opacity: historical state that is causally present but not
    # reconstructable from the present observable surface.
    opacity = sp.simplify(
        (full_state - observable_reconstruction) / (1 + full_state)
    )

    # Path dependence as sensitivity to encounter history.
    path_sensitivity = sp.diff(full_state, E)

    # Persistence half-life for inherited history.
    half_life = sp.solve(
        sp.Eq(sp.exp(-delta * D * t), sp.Rational(1, 2)), t
    )[0]

    return locals()

def main():
    ap = argparse.ArgumentParser(description="SymPy concept model for Haplopraxis.")
    ap.add_argument("--derive", action="store_true")
    args = ap.parse_args()

    m = build_model()

    print("Full historical state:")
    print(sp.pretty(m["full_state"]))
    print("\nObservable reconstruction:")
    print(sp.pretty(m["observable_reconstruction"]))
    print("\nDevelopmental opacity:")
    print(sp.pretty(m["opacity"]))
    print("\nPath sensitivity dState/dEncounter:")
    print(sp.pretty(m["path_sensitivity"]))
    print("\nInherited-history half-life:")
    print(sp.pretty(m["half_life"]))

    if args.derive:
        print("\nOpacity derivatives:")
        for name in ["H", "E", "R", "D", "t"]:
            sym = m[name]
            print(f"\ndOpacity/d{name}:")
            print(sp.pretty(sp.simplify(sp.diff(m["opacity"], sym))))

        print("\nLimiting cases:")
        print("perfect reconstruction R -> 1:")
        print(sp.pretty(sp.simplify(m["opacity"].subs(m["R"], 1))))
        print("\nno recoverability R -> 0:")
        print(sp.pretty(sp.simplify(m["opacity"].subs(m["R"], 0))))
        print("\nlate time t -> infinity:")
        print(sp.pretty(sp.limit(m["opacity"], m["t"], sp.oo)))

if __name__ == "__main__":
    main()
