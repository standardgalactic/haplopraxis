from __future__ import annotations

from pathlib import Path
import re
import subprocess
from dataclasses import dataclass
from typing import Iterable

TEXT_SUFFIXES = {
    ".txt", ".md", ".rst", ".tex", ".html", ".htm", ".css", ".js", ".ts",
    ".py", ".rs", ".sh", ".toml", ".json", ".xml", ".xsl", ".xslt", ".csv",
    ".mhtml", ".g2n"
}

SKIP_DIRS = {
    ".git", "target", "node_modules", ".venv", "venv", "__pycache__",
    "dist", "build"
}

WORD_RE = re.compile(r"[A-Za-z][A-Za-z0-9_'’-]{1,}")

@dataclass
class Doc:
    path: Path
    rel: str
    text: str

def iter_text_files(root: Path) -> Iterable[Path]:
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if any(part in SKIP_DIRS for part in p.parts):
            continue
        if p.suffix.lower() in TEXT_SUFFIXES:
            yield p

def read_text(path: Path, max_bytes: int = 5_000_000) -> str:
    try:
        data = path.read_bytes()[:max_bytes]
        return data.decode("utf-8", errors="replace")
    except OSError:
        return ""

def load_docs(root: Path) -> list[Doc]:
    docs = []
    for p in iter_text_files(root):
        text = read_text(p)
        if text.strip():
            docs.append(Doc(p, str(p.relative_to(root)), text))
    return docs

def tokenize(text: str) -> list[str]:
    return [m.group(0).lower().replace("’", "'") for m in WORD_RE.finditer(text)]

def git_first_commit_timestamp(root: Path, relpath: str) -> int | None:
    try:
        out = subprocess.check_output(
            ["git", "-C", str(root), "log", "--follow", "--format=%at", "--", relpath],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip().splitlines()
        if not out:
            return None
        return int(out[-1])
    except Exception:
        return None
