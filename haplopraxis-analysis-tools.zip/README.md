# Haplopraxis Analysis Tools

Small repository-specific analysis utilities for the `haplopraxis` repository.

The tools are intentionally biased toward the repository's actual structure:
historical strata, vocabulary drift, lineage/order dependence, recurring concepts,
and relationships among design documents, source files, corpora, and archived material.

## Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

NLTK tokenizers are optional. The text tool uses a regex tokenizer by default and
does not require downloading corpora.

## Tools

### `haplo_numpy.py`

Numerical repository archaeology. It scans text-like files and computes:

- file-size and line-count distributions
- lexical richness estimates
- pairwise cosine similarity between documents
- a similarity matrix using NumPy
- chronological "strata" summaries when Git history is available
- encounter-order sensitivity: how aggregate concept exposure changes when files
  are traversed in different orders

Example:

```bash
python haplo_numpy.py /path/to/haplopraxis --top 20
python haplo_numpy.py /path/to/haplopraxis --matrix-out similarity.csv
```

### `haplo_sympy.py`

Symbolic model explorer for Haplopraxis concepts. It turns a few central ideas
into manipulable symbolic expressions:

- state = current observable configuration + hidden historical variables
- path dependence
- decay/persistence of historical traces
- encounter-order weighting
- a simple "developmental opacity" ratio

It can also emit simplified symbolic forms and derivatives.

```bash
python haplo_sympy.py
python haplo_sympy.py --derive
```

### `haplo_nltk.py`

NLP/corpus archaeology for design notes, PDFs converted to text, source comments,
watchlists, archived text files, and README material.

It reports:

- frequent content words
- collocations
- concept concordances
- recurring concept clusters
- vocabulary unique to individual documents
- lexical overlap between selected documents
- candidate "concept migrations" where a term appears across many repository strata

```bash
python haplo_nltk.py /path/to/haplopraxis
python haplo_nltk.py /path/to/haplopraxis --concept history --concept lineage --concept opacity
```

### `haplo_analyze.py`

Runs the repository-oriented text and numerical analyses together.

```bash
python haplo_analyze.py /path/to/haplopraxis
```
